public class Main {
    public static void main(String[] args) {
        int total = 0;
        for (int i = 0; i < 101; i++) {
            total = total +i;
            System.out.print(i);
            if (i % 2 == 0) {
                System.out.println(" even");
            } else {
                System.out.println(" odd");
            }
        }
        System.out.println("Sum of values is " + total);
    }
}